#!/bin/sh
########################################
######      Edited by RAED        ######
########################################

/var/emuscript/ncam_em.sh stop

rm -rf /var/bin/ncam
rm -rf /var/emuscript/ncam_em.sh
rm -rf /var/uninstall/ncam_remove.sh

exit 0
