#!/bin/sh
dpkg -r enigma2-plugin-softcams-ncam-osdreambox
exit 0
