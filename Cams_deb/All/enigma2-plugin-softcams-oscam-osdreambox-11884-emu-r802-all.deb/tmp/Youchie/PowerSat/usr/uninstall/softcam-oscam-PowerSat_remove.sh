#!/bin/sh
dpkg -r enigma2-plugin-softcams-oscam-osdreambox
exit 0
