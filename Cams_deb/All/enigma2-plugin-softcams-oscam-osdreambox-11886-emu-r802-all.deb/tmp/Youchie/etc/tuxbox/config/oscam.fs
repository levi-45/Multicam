#################################################################################
####                    oscam.fs Patched By: Youchie                         ####
####                       https://t.me/Youchie                              ####
#################################################################################
#                             oscam.fs == CCcam.cfg                             #
#                                                                               #
# C: <hostname> <port> <username> <password> <wantemus>                         #
# N: <ip> <port> <username> <pass> <des(14byte)> <nr_of_hops_away (default: 1)> #
# R: <ip> <port> <ca4> <id6> <nr_of_hops_away (default: 1)>                     #
# L: <ip> <port> <username> <pass> <ca4> <id6> <nr_of_hops_away (default: 1)>   #
#                                                                               #
# http://<url>/... # (C, N: load rows from the URL using libcurl ...)           #
#                                                                               #
# Line Enable/Disable =? (" # ")                                                #
#################################################################################
#
#http://www.freecline.com/companies/Bis_TV
# etc...
####### preset servers #########
##    SERVER0 to SERVER20     ##
################################
