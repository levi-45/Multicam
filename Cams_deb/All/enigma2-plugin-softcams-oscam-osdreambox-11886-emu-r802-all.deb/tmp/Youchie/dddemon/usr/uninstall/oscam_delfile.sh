#!/bin/sh
########################################
######     Edited by Youchie      ######
########################################
# Type: Cam

killall -9 oscam 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/oscam
rm -rf /usr/script/oscam_cam.sh
rm -rf /usr/uninstall/oscam_delfile.sh

exit 0

