#!/bin/bash
#### "***********************************************"
#### "*       ..:: Script by MOHAMED_OS ::..        *"
#### "*  Support: https://github.com/MOHAMED19OS    *"
#### "*       E-Mail: mohamed19eng@gmail.com        *"
#### "***********************************************"
FIN="<--------------------------------------------->"

#### Binary File ####
BIN_FILES="oscam"
BIN="OSCam_11730-r799"

##### Path File #####
TMPDIR="/tmp/Levi45"
CONFIGPATH='/etc/tuxbox/config'

##### Bianry Path #####
BIN_AARCH64="${TMPDIR}/AARCH64/${BIN}"
BIN_ARM="${TMPDIR}/ARM/${BIN}"
BIN_MIPS="${TMPDIR}/MIPS/${BIN}"
BIN_SH4="${TMPDIR}/SH4/${BIN}"

#### checking your device and bin file #####
echo ${FIN}
echo ":I'm checking your device processor ..."

if uname -m | grep -qs armv7l; then
    echo ":Your Device IS ARM processor ..."
    if [ ! -f ${BIN_ARM} ]; then
        echo "Bin file Missing :("
    else
        mv -f ${BIN_ARM} ${TMPDIR} >/dev/null 2>&1
    fi
elif uname -m | grep -qs aarch64; then
    echo ":Your Device IS AARCH64 processor ..."
    if [ ! -f ${BIN_AARCH64} ]; then
        echo "Bin file Missing :("
    else
        mv -f ${BIN_AARCH64} ${TMPDIR} >/dev/null 2>&1
    fi
elif uname -m | grep -qs mips; then
    echo ":Your Device IS MIPS processor ..."
    if [ ! -f ${BIN_MIPS} ]; then
        echo "Bin file Missing :("
    else
        mv -f ${BIN_MIPS} ${TMPDIR} >/dev/null 2>&1
    fi
elif uname -m | grep -qs 7401c0; then # dm800 clone
    echo ":Your Device IS dm800 clone processor ..."
    if [ ! -f ${BIN_MIPS} ]; then
        echo "Bin file Missing :("
    else
        mv -f ${BIN_MIPS} ${TMPDIR} >/dev/null 2>&1
    fi
elif uname -m | grep -qs sh4; then
    echo ":Your Device IS SH4 processor ..."
    if [ ! -f ${BIN_SH4} ]; then
        echo "Bin file Missing :("
    else
        mv -f ${BIN_SH4} ${TMPDIR} >/dev/null 2>&1
    fi
else
    echo "Sorry, your device does not have the proper Emu :("
    rm -rf ${TMPDIR} >/dev/null 2>&1
    exit 1
fi

####
if [ -r /usr/lib/enigma2/python/Plugins/Extensions/Manager ]; then
    cp -rf ${TMPDIR}/Levi45/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
else
    rm -r ${TMPDIR} >/dev/null 2>&1
    echo "No emu script to this image now .. ask about it :("
    rm -rf /tmp/enigma2-plugin-softcams-oscam*.ipk
    exit 1
fi

#### Checking Config Files ####
if [ ! -d ${CONFIGPATH} ]; then
    mkdir -p ${CONFIGPATH} >/dev/null 2>&1
fi

echo ${FIN}
echo ":I'm checking your config OSCam ..."
for file in ${BIN_FILES}.conf ${BIN_FILES}.dvbapi ${BIN_FILES}.provid ${BIN_FILES}.server ${BIN_FILES}.services ${BIN_FILES}.user CCcam.cfg; do
    if [ ! -f "${CONFIGPATH}/${file}" ]; then
        cp -f "${TMPDIR}${CONFIGPATH}/${file}" $CONFIGPATH >/dev/null 2>&1
        echo "  send: ${file} ... file"
    fi
done
echo ${FIN}

#### Checking OpenPLI Softcam Symlink ####
if [ -f /etc/init.d/softcam.None ]; then
    if type update-rc.d 2>/dev/null; then
        if [ -n "${D}" ]; then
            OPT="-r ${D}"
        else
            OPT="-s"
        fi
        update-rc.d "${OPT}" softcam defaults 50 >/dev/null 2>&1
    fi
fi
