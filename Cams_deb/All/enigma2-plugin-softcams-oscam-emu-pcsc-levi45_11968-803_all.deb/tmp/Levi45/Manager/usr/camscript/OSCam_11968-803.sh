#!/bin/sh
#### "***********************************************"
#### "*              Moded by Levi45                *"
#### "***********************************************"

OSD="OSCam_11968-803"
PID=$(pidof ${OSD})
Action=$1
chmod 755 /usr/bin/OSCam_11968-803
cam_clean() {
	rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

cam_handle() {
	if test -z "${PID}"; then
		cam_up
	else
		cam_down
	fi
}

cam_down() {
	killall -9 OSCam_11968-803
	sleep 2
	cam_clean
}

cam_up() {
	cam_clean
	/usr/bin/OSCam_11968-803 &
}

if test "$Action" = "cam_startup"; then
	if test -z "${PID}"; then
		cam_down
		cam_up
	else
		echo "oscam already running, exiting..."
	fi
elif test "$Action" = "cam_res"; then
	cam_down
	cam_up
elif test "$Action" = "cam_down"; then
	cam_down
elif test "$Action" = "cam_up"; then
	cam_up
else
	cam_handle
fi

exit 0
