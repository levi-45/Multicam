#!/bin/sh
#### "***********************************************"
#### "*             Created by Levi45               *"
#### "***********************************************"

# Set up logging
LOG_FILE="/tmp/oscam_boot.log"
echo "===== $(date) ===== OSCam Startup Script =====" > $LOG_FILE

# OSCam binary location
OSD="OSCam_11959-803"
OSCAM_BINARY="/usr/bin/OSCam_11959-803"
OSCAM_NAME="OSCam_11959-803"
PID=""
Action="$1"

echo "Action received: $Action" >> $LOG_FILE
echo "OSCam binary: $OSCAM_BINARY" >> $LOG_FILE

# Make sure binary is executable
chmod 755 "$OSCAM_BINARY" 2>/dev/null

# Function to get PID
get_pid() {
    PID=$(pidof "$OSCAM_NAME")
    echo "Current PID: $PID" >> $LOG_FILE
}

# Clean temp files
cam_clean() {
    echo "Cleaning temp files..." >> $LOG_FILE
    rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam 2>/dev/null
}

# Stop OSCam
cam_down() {
    echo "Stopping OSCam..." >> $LOG_FILE
    get_pid
    if [ -n "$PID" ]; then
        kill -9 "$PID" 2>/dev/null
        echo "Killed process $PID" >> $LOG_FILE
    fi
    sleep 2
    # Make sure it's really stopped
    killall -9 "$OSCAM_NAME" 2>/dev/null
    cam_clean
}

# Start OSCam with retry
cam_up() {
    echo "Starting OSCam..." >> $LOG_FILE
    cam_clean
    
    # Start OSCam
    "$OSCAM_BINARY" >> $LOG_FILE 2>&1 &
    echo "Started OSCam with PID: $!" >> $LOG_FILE
    
    # Wait and check if it's running
    sleep 5
    get_pid
    
    if [ -n "$PID" ]; then
        echo "SUCCESS: OSCam is running with PID: $PID" >> $LOG_FILE
        return 0
    else
        echo "WARNING: OSCam might not have started, retrying..." >> $LOG_FILE
        # Try one more time
        "$OSCAM_BINARY" >> $LOG_FILE 2>&1 &
        sleep 3
        get_pid
        
        if [ -n "$PID" ]; then
            echo "SUCCESS: OSCam started on retry with PID: $PID" >> $LOG_FILE
        else
            echo "ERROR: Failed to start OSCam after retry" >> $LOG_FILE
            return 1
        fi
    fi
}

# Handle based on action
case "$Action" in
    "cam_startup")
        echo "Boot startup sequence..." >> $LOG_FILE
        # Wait a bit for system to stabilize
        sleep 10
        cam_down
        cam_up
        ;;
    "cam_restart"|"cam_res")
        echo "Restart requested..." >> $LOG_FILE
        cam_down
        sleep 2
        cam_up
        ;;
    "cam_stop"|"cam_down")
        echo "Stop requested..." >> $LOG_FILE
        cam_down
        ;;
    "cam_start"|"cam_up")
        echo "Start requested..." >> $LOG_FILE
        cam_up
        ;;
    *)
        echo "No valid action specified, checking status..." >> $LOG_FILE
        get_pid
        if [ -z "$PID" ]; then
            echo "OSCam not running, starting it..." >> $LOG_FILE
            cam_up
        else
            echo "OSCam already running with PID: $PID" >> $LOG_FILE
        fi
        ;;
esac

echo "Script finished at $(date)" >> $LOG_FILE
exit 0
